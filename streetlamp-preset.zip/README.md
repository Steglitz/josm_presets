# street_lamps_preset_JOSM
A preset template for adding street lamps in JOSM or Vespucci. 
